chm2web Standard 2.85 - HTML Help conversion utility
==============================================================

Developer : A!K Research Labs. Copyright(c) 2002-2009

License : Evaluation

Supported OS : Windows 98/ME/NT/2000/XP/2003/Vista/Win7

Microsoft Internet Explorer  4.01 or later should be installed
to run the program.

==============================================================

DESCRIPTION :

Using  chm2web you can convert documentation in the chm format
(html     help)    into    a    full-featured    browser-based
platform-independent  html  help  system that can be viewed in
any  modern  web  browser.  The  set  of HTML files created by
chm2web  can  be  as  well uploaded to your web server or used
locally as a help system for your products. 

==============================================================

LAST CHANGES - HISTORY: 

Aug 3, 2009 - version 2.85, build 233
- Incorrect "see also" links conversion was fixed (help 
  index tab).
+ More detailed error reporing have been added.

Jun 16, 2009 - version 2.84, build 229
+ Windows7 compatibility issues were fixed.
+ Help file is updated and included in the installation package.
* Some minor bugs were fixed.

May 11, 2009 - version 2.83, build 226
- Incorrect Modern template resizing is fixed.

Mar 26, 2009 - version 2.82, build 225
- "Unable to convert TOC" error on some valid help files was
  fixed. 

Mar 24, 2009 - version 2.82, build 224
+ New option: "Tabs\Expand all root nodes on load"
* All templates retested with IE8, Chrome, Firefox and Opera and
  all found issues were fixed. Now all templates can be resized 
  correctly in all browsers.
- Some minor bugs were fixed too.

Mar 5, 2009 - version 2.81, build 218
- "Unable to copy \.\files\blankpage.html" error was fixed.
- Quiet template is modified, so it's resizable now.

Sep 26, 2008 - version 2.8, build 212
* Search index creation process is now up to 10 times faster.
* Unicode support was improved. 
+ Subitems in help index are supported now.
- Many compatibility problems was fixes.

Jun 9, 2008 - version 2.76, build 206
- Many compatibility problems was fixes.

Mar 27, 2008 - version 2.75, build 202
- Incorrect links was generated sometimes. It's fixed now.

Mar 17, 2008 - version 2.75, build 201
* Major bug fix.

Feb 07, 2008 - version 2.75, build 196
* The update is strongly recommended for all chm2web 2.74+ users.
- Bug with non-latin file processing are fixed.
- Compatibility tab has been added.
- xml tag is now supported.

Feb 04, 2008 - version 2.74, build 194
- The build process is stopped before the end with the error 
  'Cannot create file c:\outfile.txt'

Jan 31, 2008 - version 2.74, build 193
+ Server side scripting (php) is now supported (useful for
  large help systems).
- Many minor bugs has been fixed.

Nov 16, 2007 - version 2.73, build 188
+ Default Charset option has been added.
- Unicode support has been improved.
- A few minor bugs has been fixed.

Oct 14, 2007 - version 2.72, build 187
- Minor bug fix

Sep 29, 2007 - version 2.72, build 185
- Wrong index generation is fixed.
- Some other small bugs has been fixed too.

Aug 14, 2007 - version 2.72, build 183
+ Minor changes in the interface have been made.
- Sometimes the titles of found pages in search results turned
  out to be empty.
- Minor visual bug in the Modern template is fixed.
- Some minor compatiblity bugs has been fixed.

May 04, 2007 - version 2.7, build 176
- Critical bug in a full-text search engine is fixed. We 
  strongly recommend that all users upgrade to these release.

Apr 15, 2007 - version 2.7, build 174
* Final release. 
+ Full unicode support has been added (search on
  asian character sets are not supported yet, sorry).
+ HTML cleaning engine has been added. 
+ Windows Vista is now fully supported.
* Many compatibility issues were resolved.
* Help file was updated.
* Decompilation output has been extened.
- Many minor and major bugs were fixed. 

Aug 27, 2006 - version 2.7 beta, build 171 
+ Minor bug fix.

Oct 22, 2005 - version 2.7 prebeta, build 169 
* New search engine.
* New indexing engine.
+ Minor bug fix.

May 30, 2005 - version 2.6, build 167 
* Final release.
+ Minor bug fix.

May 20, 2005 - version 2.6, build 166 beta
+ Minor bug fix.

Mar 14, 2005 - version 2.6, build 160 beta
+ The button for printing the current page is added to all standard 
  templates.
+ Now chm2web Pro allows you to convert merged help systems, i.e. 
  systems consisting of several separate chm files.
+ The "Build" tab where the last "Build" command is logged is added.
+ Now it is possible to hide the "Index" tab in the help system.
- The problems of compatibility with some chm generating software 
  are fixed.
- Other minor bugs are also fixed.

Dec 18, 2004 - version 2.46, build 153
* Compatibility problems with html files generated
  by Microsoft Office Word has been resolved.

Nov 24, 2004 - version 2.46, build 151
+ The option "When user opens a page using 
  a direct link... Just open the page" is added.
- Occasional problems with resizing the 
  contents in the "Modern" template are fixed.
- A lot of compatibility bugs are fixed.
- The bug when chm2web could not sometimes 
  find the toc file with the help contents 
  is fixed.
- Some other minor bugs are also fixed.

Aug 29, 2004 - version 2.45, build 147
* Final release

Aug 20, 2004 - version 2.45, build 143 beta
* Two new templates: Industrial and Quiet.
* Many compatibility issues have been resolved.
- Many minor and major bugs have been fixed.

May 05, 2004 - version 2.40.fix2, build 136
* Minor bug fix

Mar 30, 2004 - version 2.40.fix1, build 133
* chms generated with HelpStudio by Innovasys are now supported.
* Minor bugs have been fixed.

Mar 22, 2004 - version 2.40, build 131
* Help file has been updated.
- Minor bugs have been fixed.
  Installing this update is strongly recommended.

Mar 16, 2004 - version 2.40, build 129 RC2
* All templates have a valid w3c HTML 4.01 code now.
* Minor bug fix.
  Installing this update is strongly recommended.

Mar 08, 2004 - version 2.40, build 128 beta
* Another major bug fix. 
  Installing this update is strongly recommended.

Jan 24, 2004 - version 2.40, build 123 beta
* Major bug fix. 

Oct 17, 2003 - version 2.30, build 116 beta
+ Now it's possible to extract auxiliary files using the "Compiled   
  Help Decompilation" dialog. 
+ New template: Modern orange
+ Binary index tree support has been added.
+ Doc-To-Help support has been added.
- A few minor bugs has been fixed.

Sep 05, 2003 - version 2.30, build 112 beta
+ Better help index support. Now it's possible to use "see also" 
  links.
* Added captions to the Index and Search tabs.
- Some bugs in the search engine has been fixed.
- Some other bugs has been fixed too.

Aug 09, 2003 - version 2.30, build 111 beta
* Now it's possible to search keywords in the help index tab.
* Windows Green theme has been updated.
* A few bugs are fixed.

Aug 01, 2003 - version 2.30, build 110 beta
+ New help decompilation engine
* Conversion engine has been optimized, so now it works faster 
  than ever.
* A few bugs are fixed.

Jul 21, 2003 - version 2.30, build 107 beta
+ Search tab has been added to the frames version of the help 
  system.
+ "Sync contents" button has been added.
+ Many small changes
- A few minor and major bugs are fixed. 

Apr 16, 2003 - version 2.18, build 96
+ The script displaying the help file contents is improved and
  reduced in size.
+ Now  you   can  specify  if  you  want  the root nodes to be
  expanded when help is started.
+ Help systems made  with the program are now better optimized 
  for search engines.
- Few minor bugs are fixed.
                           
Feb 21, 2003 - version 2.16 fix3, build 91
- Files made with Help&Manual 3.x. are now supported.
- Some minor bugs were fixed.

Jan 25, 2003 - version 2.16 fix2, build 90
 + Some minor bugs were fixed.

Jan 10, 2003 - version 2.16 fix1, build 89
 + Some minor bugs were fixed.

Dec 31, 2002 - version 2.16, build 88
 + Accented characters conversion added.
 - Major bug of templates engine is fixed. 

Dec 22, 2002 - version 2.15, build 86
 + New featured templates: Windows Classic and Windows Green
 * Some template variables are changed. See help for details.
 * Application icon is updated.
 * Minor bug fixes.

Dec 10, 2002 - version 2.1, build 82
 + Page preprocessor is added (see screenshots) 
 * New templates: Corporate Blue, Corporate Red and Default Red 
 - Minor bug fixes. 

29 Aug 2002 - version 1.46
 + More chm sub-formats are supported. 
 - bug fixes

19 Aug 2002 - version 1.45
 + chm2web can generate javascript tree of contents.
 + Conversion speed is increased.
 + Links in contents is now supported.
 + chm2web can add headers to pages, missed in contents.
 - Some minor bugs is fixed

18 July 2002 - version 1.4
 + Interface is updated
 + Help system is updated
 - Some minor bugs were fixed

12 July 2002 - version 1.3
 + New option 'Generate mobile version' added. Allow you read
   chm help on your PocketPC or HPC.
 + Convert faster.
 - Some bugs were fixed.

02 July 2002 - version 1.2
 + Projects support added
 + Command prompt support added
 + 'Keywords' meta-tag support added
 + New option 'open pages only in frameset' added
 - Slightly corrected banner placement in resulting online help system
 - All known bugs fixed

19 June 2002 - version 1.1
 + Added "no frames" option
 - some minor bugs were fixed

06 June 2002 - version 1.0
 + Tested on Windows 98 + Internet Explorer 5.0
 + Tested on Windows ME
 + Tested on Windows NT 4.0 + Internet Explorer 5.0
 + Tested on Windows 2000
 + Tested on Windows XP 

==============================================================

Installation:

 * Run SETUP.EXE and follow the instructions.
 * Read through the Help file.

==============================================================

Uninstallation:

  - Use the Windows control panel's 'Add/Remove program' feature.

==============================================================

Our contacts :
                        
  Web page     : http://chm2web.aklabs.com 
  Support      : http://tickets.aklabs.com

==============================================================
   Copyright(c), A!K Research Labs (www.aklabs.com). 2002-2007
